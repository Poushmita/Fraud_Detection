from pathlib import Path

import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "creditcard.csv"


def load_data(path=DATA_PATH):
    if not Path(path).exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. "
            "Download the public Credit Card Fraud Detection dataset "
            "and place creditcard.csv inside data/."
        )

    df = pd.read_csv(path)
    print(f"Dataset shape: {df.shape}")
    print("\nMissing values:", int(df.isna().sum().sum()))

    return df


def prepare_data(df):
    if "Class" not in df.columns:
        raise ValueError("Expected target column 'Class' was not found.")

    X = df.drop(columns=["Class"])
    y = df["Class"]

    # Standardize Amount; Time is retained as a model feature for the baseline.
    if "Amount" in X.columns:
        scaler = StandardScaler()
        X["Amount"] = scaler.fit_transform(X[["Amount"]])

    return X, y


def main():
    df = load_data()

    print("\nClass distribution:")
    print(df["Class"].value_counts())
    print("\nClass proportions:")
    print(df["Class"].value_counts(normalize=True).round(4))

    X, y = prepare_data(df)

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y,
    )

    print(f"\nTraining samples: {len(X_train):,}")
    print(f"Testing samples:  {len(X_test):,}")

    model = LogisticRegression(
        max_iter=1000,
        class_weight="balanced",
        random_state=42,
    )

    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]

    print("\n=== Baseline Classification Report ===")
    print(classification_report(y_test, predictions, digits=4))

    print("=== Confusion Matrix ===")
    print(confusion_matrix(y_test, predictions))

    print("\nROC-AUC:", round(roc_auc_score(y_test, probabilities), 4))


if __name__ == "__main__":
    main()
