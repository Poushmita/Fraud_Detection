# Fraud Detection System

An AI/ML project for detecting fraudulent financial transactions using classification techniques on highly imbalanced transaction data.

## Project Status

**Milestone: 25% — Initial submission**

Completed in this milestone:
- Project structure and documentation
- Transaction dataset loading pipeline
- Data quality checks
- Class-imbalance analysis
- Exploratory data analysis
- Train/test split with stratification
- Baseline Logistic Regression model
- Initial Precision, Recall, F1-score and ROC-AUC evaluation

Planned for later milestones:
- Compare multiple ML models
- Precision-Recall curve and PR-AUC
- Cost-sensitive threshold optimization
- Business-cost matrix for false positives/false negatives
- Explainable fraud-risk predictions
- REST API
- Web dashboard
- Database integration
- Docker/deployment

## Problem Statement

Fraud detection is a binary classification problem where fraudulent transactions are usually much rarer than legitimate transactions. Because of this class imbalance, accuracy alone can be misleading.

The goal of this project is to build a transaction classifier and eventually choose a decision threshold based on the business cost of false positives and false negatives.

## Dataset

The code expects a CSV file at:

`data/creditcard.csv`

The recommended dataset is the public **Credit Card Fraud Detection** dataset from Kaggle:

https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud

The dataset contains anonymized transaction features and a `Class` target:
- `0` = legitimate transaction
- `1` = fraud

**Do not upload the dataset itself to GitHub.** Place it locally in `data/creditcard.csv`.

## Run Locally

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

Install dependencies:
```bash
pip install -r requirements.txt
```

Run the baseline:
```bash
python src/train_baseline.py
```

For the EDA notebook:
```bash
jupyter notebook
```

Then open:
`notebooks/01_eda_baseline.ipynb`

## Important Note

This repository represents the **initial 25% milestone**, not the final production system. The next stage will focus on model comparison and business-aware threshold optimization rather than simply maximizing accuracy.
